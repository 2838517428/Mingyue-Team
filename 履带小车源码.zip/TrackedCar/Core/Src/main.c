/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "tim.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "ps2.h"
#include "motor.h"
/* USER CODE END Includes */
/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
static int axis_speed(uint8_t raw)
{
  int d = 128 - (int)raw;
  if (d >= -20 && d <= 20) return 0;
  int mag = d > 0 ? d : -d;
  int out = (mag - 20) * 1000 / 107;
  if (out > 1000) out = 1000;
  return d > 0 ? out : -out;
}
/* Retain last direction and require 100ms at zero before reversal. */
static int motor_guard(unsigned i, int request, uint32_t now)
{
  static int last_sign[4], applied[4];
  static uint32_t stopped[4];
  int sign = request > 0 ? 1 : request < 0 ? -1 : 0;
  if (!request || (last_sign[i] && sign != last_sign[i])) {
    if (applied[i]) stopped[i] = now;
    applied[i] = 0;
    if (!request || (uint32_t)(now - stopped[i]) < 100u) return 0;
  }
  last_sign[i] = sign;
  applied[i] = request;
  return request;
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM2_Init();
  MX_TIM3_Init();
  MX_TIM4_Init();
  /* USER CODE BEGIN 2 */
  /* Integrated controller; all CCRs set safely before PWM starts. */
  __HAL_RCC_AFIO_CLK_ENABLE();
  __HAL_AFIO_REMAP_SWJ_NOJTAG();
  Car_Move(0, 0);
  Independent_Motor_Set(1, 0);
  Independent_Motor_Set(2, 0);
  __HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_1, 1500u);
  __HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_2, 1000u);
  if (HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_1) != HAL_OK) Error_Handler();
  if (HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_2) != HAL_OK) Error_Handler();
  if (HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_1) != HAL_OK) Error_Handler();
  if (HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_2) != HAL_OK) Error_Handler();
  if (HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_1) != HAL_OK) Error_Handler();
  if (HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_2) != HAL_OK) Error_Handler();
  GPIO_InitTypeDef safe_gpio = {0};
  safe_gpio.Mode = GPIO_MODE_OUTPUT_PP;
  safe_gpio.Pull = GPIO_NOPULL;
  safe_gpio.Speed = GPIO_SPEED_FREQ_LOW;
  __HAL_RCC_GPIOC_CLK_ENABLE();
  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_SET);
  safe_gpio.Pin = GPIO_PIN_13;
  HAL_GPIO_Init(GPIOC, &safe_gpio);
  HAL_Delay(500);
  (void)PS2_Init();
  uint32_t boot_at = HAL_GetTick();
  uint32_t released_at = boot_at, started_at = 0, last_retry = boot_at;
  uint8_t good_frames = 0, armed = 0, running = 0, locked = 0;
  uint8_t fan_ready = 0, servo_on = 1, previous_square = 0, previous_circle = 0;
  uint16_t servo_target = 1500u;
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
    uint8_t valid = PS2_ReadData();
    uint32_t now = HAL_GetTick();
    if (valid && PS2_L2) locked = 1;
    valid = valid && (PS2_Data[1] == 0x73u || PS2_Data[1] == 0x79u);
    int desired[4] = {0}, output[4];
    uint8_t square = 0, circle = 0, triangle = 0;
    if (valid) {
      if (good_frames < 3u) good_frames++;
      square = PS2_SQUARE; circle = PS2_CIRCLE; triangle = PS2_TRIANGLE;
    } else good_frames = 0;
    uint8_t neutral = valid && axis_speed(PS2_LY()) == 0 && axis_speed(PS2_RY()) == 0 &&
      !PS2_UP && !PS2_DOWN && !PS2_LEFT && !PS2_RIGHT && !square && !circle && !triangle;
    if (!valid || locked) {
      armed = 0; running = 0; fan_ready = 0; released_at = now;
      if (servo_on) {
        HAL_TIM_PWM_Stop(&htim4, TIM_CHANNEL_1);
        servo_on = 0;
      }
    } else if (!armed) {
      if ((uint32_t)(now - boot_at) < 5000u || good_frames < 3u || !neutral) released_at = now;
      else if ((uint32_t)(now - released_at) >= 300u) {
        armed = 1; fan_ready = 1;
        if (!servo_on) {
          __HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_1, servo_target);
          if (HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_1) != HAL_OK) Error_Handler();
          servo_on = 1;
        }
      }
    }
    if (armed && !locked && valid) {
      desired[0] = axis_speed(PS2_LY());
      desired[1] = axis_speed(PS2_RY());
      desired[2] = (PS2_UP ? 1000 : 0) - (PS2_DOWN ? 1000 : 0);
      desired[3] = (PS2_LEFT ? 1000 : 0) - (PS2_RIGHT ? 1000 : 0);
      if (circle) servo_target = 1500u;
      else if (square && !previous_square) servo_target = 500u;
      __HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_1, servo_target);
      if (!triangle) { running = 0; fan_ready = 1; }
      else if (running) {
        if ((uint32_t)(now - started_at) >= 5000u) running = 0;
      } else if (fan_ready) {
        running = 1; fan_ready = 0; started_at = now;
      }
    }
    previous_square = square; previous_circle = circle;
    (void)previous_circle;
    /* Clear CCR before any direction transitions; guard enforces reversal dwell. */
    for (unsigned i = 0; i < 4; i++) output[i] = motor_guard(i, desired[i], now);
    __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1, 0);
    __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_2, 0);
    __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, 0);
    __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, 0);
    Car_Move(output[0], output[1]);
    Independent_Motor_Set(1, output[2]);
    Independent_Motor_Set(2, output[3]);
    __HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_2, running ? 1400u : 1000u);
    if (!valid && (uint32_t)(now - last_retry) >= 2000u) {
      (void)PS2_Init(); last_retry = HAL_GetTick();
    }
    uint32_t interval = locked ? 50u : (!valid ? 100u : 500u);
    uint8_t led_on = armed ? 1u : ((now / interval) % 2u == 0u);
    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, led_on ? GPIO_PIN_RESET : GPIO_PIN_SET);
    HAL_Delay(5);
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
