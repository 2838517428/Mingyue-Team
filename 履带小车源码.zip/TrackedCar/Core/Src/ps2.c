/* ============================================================
 * ps2.c  ——  CRTC2026 履带车：PS2 手柄驱动实现
 * 版本：CRTC-PS2 v4   2026-10-16
 * 位置：Core/Src/ps2.c
 * 别忘了把本文件加进 CMakeLists.txt 的 target_sources()
 * ============================================================ */

#include "ps2.h"

/* ---- 版本自检：头文件没换新时只报一条中文错误 ---- */
#if !defined(PS2_R1) || !defined(PS2_LY)
#error "ps2.h 版本过旧：缺少按键/摇杆宏。请用 v4 版 ps2.h 覆盖 Core/Inc/ps2.h 后重新编译。"
#endif

/* ================= 引脚定义 ================= */
#define PS2_DAT_PORT  GPIOB
#define PS2_DAT_PIN   GPIO_PIN_12   /* DAT: 输入，必须上拉 */
#define PS2_CMD_PORT  GPIOB
#define PS2_CMD_PIN   GPIO_PIN_13   /* CMD: 推挽输出 */
#define PS2_CS_PORT   GPIOB
#define PS2_CS_PIN    GPIO_PIN_14   /* CS : 推挽输出 */
#define PS2_CLK_PORT  GPIOB
#define PS2_CLK_PIN   GPIO_PIN_15   /* CLK: 推挽输出，空闲高 */

#define CS_L()   HAL_GPIO_WritePin(PS2_CS_PORT,  PS2_CS_PIN,  GPIO_PIN_RESET)
#define CS_H()   HAL_GPIO_WritePin(PS2_CS_PORT,  PS2_CS_PIN,  GPIO_PIN_SET)
#define CLK_L()  HAL_GPIO_WritePin(PS2_CLK_PORT, PS2_CLK_PIN, GPIO_PIN_RESET)
#define CLK_H()  HAL_GPIO_WritePin(PS2_CLK_PORT, PS2_CLK_PIN, GPIO_PIN_SET)
#define CMD_L()  HAL_GPIO_WritePin(PS2_CMD_PORT, PS2_CMD_PIN, GPIO_PIN_RESET)
#define CMD_H()  HAL_GPIO_WritePin(PS2_CMD_PORT, PS2_CMD_PIN, GPIO_PIN_SET)
#define DAT_RD() HAL_GPIO_ReadPin(PS2_DAT_PORT,  PS2_DAT_PIN)

uint8_t PS2_Data[9];

/* ============================================================
 * 微秒延时：Cortex-M3 的 DWT 周期计数器
 * ------------------------------------------------------------
 * 不要用 while(cnt--) __NOP()：那个循环每圈 4~6 个周期，
 * 在 72MHz 下实际延时只有目标的 1/2 ~ 1/4，而且随 CLion 的
 * -O0/-O2/-Os 优化等级变化。DWT 方案与优化等级完全无关。
 * ============================================================ */
static void PS2_DelayInit(void)
{
    CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;   /* 打开跟踪单元 */
    DWT->CYCCNT = 0;
    DWT->CTRL  |= DWT_CTRL_CYCCNTENA_Msk;             /* 启动周期计数 */
}

static void PS2_DelayUs(uint32_t us)
{
    uint32_t start = DWT->CYCCNT;
    uint32_t ticks = us * (SystemCoreClock / 1000000UL);   /* 72MHz -> 72 拍/us */
    while ((DWT->CYCCNT - start) < ticks) { }
}

/* ============================================================
 * 模拟 SPI：收发 1 字节
 * ------------------------------------------------------------
 * 时序：主机先摆好 CMD -> CLK 拉低（下降沿，从机送出数据位）
 *       -> 主机采样 DAT -> CLK 拉高（回空闲）
 * ============================================================ */
static uint8_t PS2_Cmd(uint8_t cmd)
{
    uint8_t res = 0;
    uint8_t ref;

    for (ref = 0x01; ref != 0; ref <<= 1)
    {
        if (cmd & ref) CMD_H(); else CMD_L();
        PS2_DelayUs(2);
        CLK_L();                    /* 下降沿：从机更新 DOUT */
        PS2_DelayUs(4);
        if (DAT_RD()) res |= ref;   /* 主机采样 */
        CLK_H();                    /* 回空闲高电平 */
        PS2_DelayUs(4);
    }
    PS2_DelayUs(10);
    return res;
}

/* ============================================================
 * 发一条完整命令包
 * ------------------------------------------------------------
 * 【关键】每条配置包都必须独立拉低/拉高 CS。
 * 若像常见写法那样全程只拉低一次、连发 4 组命令，手柄根本
 * 不会进入配置模式 —— 表现为"摇杆永远是中位、只有方向键能用"。
 * ============================================================ */
static void PS2_Packet(const uint8_t *p, uint8_t len)
{
    uint8_t i;

    CS_L();
    PS2_DelayUs(16);
    for (i = 0; i < len; i++) PS2_Cmd(p[i]);
    CS_H();
    PS2_DelayUs(16);
}

/* ============================================================
 * 读一帧数据
 * ============================================================ */
uint8_t PS2_ReadData(void)
{
    uint8_t i;
    uint8_t id_ok;
    uint8_t ready;

    CS_L();
    PS2_DelayUs(16);
    PS2_Data[0] = PS2_Cmd(0x01);            /* 起始字节 */
    PS2_Data[1] = PS2_Cmd(0x42);            /* 请求数据，返回模式 ID */
    PS2_Data[2] = PS2_Cmd(0x00);            /* 应为 0x5A（就绪） */
    for (i = 3; i < 9; i++) PS2_Data[i] = PS2_Cmd(0x00);
    CS_H();
    PS2_DelayUs(16);

    id_ok = (PS2_Data[1] == 0x41) || (PS2_Data[1] == 0x73) || (PS2_Data[1] == 0x79);
    ready = (PS2_Data[2] == 0x5A);

    return (id_ok && ready) ? 1u : 0u;
}

/* ============================================================
 * 初始化：进入模拟（红灯）模式
 * ============================================================ */
uint8_t PS2_Init(void)
{
    static const uint8_t enterCfg[]   = {0x01, 0x43, 0x00, 0x01, 0x00};
    static const uint8_t analogMode[] = {0x01, 0x44, 0x00, 0x01, 0x03, 0x00, 0x00, 0x00, 0x00};
    static const uint8_t setVibrat[]  = {0x01, 0x4D, 0x00, 0x00, 0x01, 0xFF, 0xFF, 0xFF, 0xFF};
    static const uint8_t exitCfg[]    = {0x01, 0x43, 0x00, 0x00, 0x5A, 0x5A, 0x5A, 0x5A, 0x5A};
    uint8_t i, retry;

    PS2_DelayInit();
    for (i = 0; i < 9; i++) PS2_Data[i] = 0;

    CS_H(); CLK_H(); CMD_H();       /* 先让总线处于空闲态 */
    PS2_DelayUs(20000);             /* 等手柄上电稳定 */

    for (retry = 0; retry < 3; retry++)      /* 手柄可能没插好，重试 3 轮 */
    {
        PS2_Packet(enterCfg,   sizeof(enterCfg));   PS2_DelayUs(2000);
        PS2_Packet(analogMode, sizeof(analogMode)); PS2_DelayUs(2000);
        PS2_Packet(setVibrat,  sizeof(setVibrat));  PS2_DelayUs(2000);
        PS2_Packet(exitCfg,    sizeof(exitCfg));    PS2_DelayUs(2000);

        for (i = 0; i < 5; i++)
        {
            if (PS2_ReadData()) return 1u;          /* 握手成功 */
            PS2_DelayUs(20000);
        }
    }
    return 0u;
}
