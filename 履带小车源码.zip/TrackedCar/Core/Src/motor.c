/* ============================================================
 * motor.c  ——  CRTC2026 履带车：电机 / 舵机 / 涵道 驱动 + 遥控任务
 * 版本：CRTC-FW v4   2026-10-16
 * 位置：Core/Src/motor.c
 *
 * ============================================================
 * 【main.c 集成，只改三处】
 * ============================================================
 *   1) 在 USER CODE BEGIN Includes 区加：
 *          #include "motor.h"
 *   2) 在 USER CODE BEGIN 2 区加：
 *          Robot_Init();
 *   3) 在 while(1) 里加：
 *          Robot_Loop();          // 内部自带 20ms 节流
 *      注意：不要再叠加 HAL_Delay 或其它长阻塞代码。
 *
 * ============================================================
 * 【CMakeLists.txt 补三行】
 * ============================================================
 *   target_sources(${CMAKE_PROJECT_NAME} PRIVATE
 *           ... 原有内容 ...
 *           ${CMAKE_CURRENT_SOURCE_DIR}/Core/Src/motor.c
 *           ${CMAKE_CURRENT_SOURCE_DIR}/Core/Src/ps2.c
 *   )
 *   改完在 CLion 里 File -> Reload CMake Project。
 *   注意：CubeMX 生成的 target_sources() 是"显式列举"，新建 .c 不会自动编译。
 *
 * ============================================================
 * 【CubeMX 必查清单】
 * ============================================================
 *   TIM2  CH1=PA0  CH2=PA1   PWM Generation，PSC=71 ARR=999（1kHz）
 *                            不要开 CH3/CH4
 *   TIM3  CH1=PA6  CH2=PA7   同上 PSC=71 ARR=999
 *   TIM4  CH1=PB6  CH2=PB7   PWM Generation，PSC=71 ARR=19999（50Hz，
 *                            1 个计数 = 1us，所以 CCR 直接就是微秒数）
 *   PB0/PB1、PB10/PB11       GPIO_Output   履带方向
 *   PB4/PB5、PB8/PB9         GPIO_Output   独立电机方向（PB4 需代码释放 JTAG）
 *   PB12 (DAT)               GPIO_Input + Pull-up   ← 浮空必然通信失败
 *   PB13/PB14/PB15           GPIO_Output 推挽（CMD/CS/CLK）
 *   时钟 72MHz（HSE+PLL）
 *   电机驱动板 STBY 脚必须拉高，否则驱动完全不工作
 *
 * ============================================================
 * 【上电验证顺序，务必按顺序，别一次全接】
 * ============================================================
 *   ① 只验 PWM：临时写成 while(1){ Car_Move(400,400); } 看履带是否稳定前转
 *   ② 验手柄  ：串口打印 PS2_Data[1]（期望 0x41）、PS2_Data[2]（期望 0x5A）
 *   ③ 再接舵机：上电应立即回中不抖（舵机要独立 5V，别吃 STM32 的 5V）
 *   ④ 最后接涵道电调：先不装叶轮！STM32 先输出 1000us 再给电调上电，
 *      听到"哔-哔"两声 = 解锁成功，确认 R1 点射 3 秒会自动收油门后再装叶轮
 * ============================================================ */

#include "motor.h"
#include "ps2.h"

/* ------------------------------------------------------------
 * 版本自检
 * ------------------------------------------------------------
 * 若 Core/Inc/ 下的 motor.h 或 ps2.h 还是旧版，编译器原本会在下面
 * 刷出十几条 "use of undeclared identifier"，一行行去数非常费劲。
 * 这里拦在最前面，只报一条中文错误。
 * ------------------------------------------------------------ */
#if !defined(FAN_US_MAX) || !defined(SERVO_US_MAX) || !defined(SPEED_FULL)
#error "motor.h 版本过旧：缺少 FAN_US_MAX / SERVO_US_MAX / SPEED_FULL。请用 v4 版 motor.h 覆盖 Core/Inc/motor.h 后重新编译。"
#endif

#if !defined(PS2_R1) || !defined(PS2_LY)
#error "ps2.h 版本过旧：缺少按键/摇杆宏。请用 v4 版 ps2.h 覆盖 Core/Inc/ps2.h 后重新编译。"
#endif

extern TIM_HandleTypeDef htim2;   /* 履带     PA0 / PA1     */
extern TIM_HandleTypeDef htim3;   /* 独立电机 PA6 / PA7     */
extern TIM_HandleTypeDef htim4;   /* 舵机 PB6 / 涵道电调 PB7 */

/* ============================================================
 *                     第一部分：驱动层
 * ============================================================ */

/* ------------------------------------------------------------
 * 工具：速度千分比 -> CCR（与 ARR 无关）
 * ------------------------------------------------------------
 * v 的量纲固定为 -SPEED_FULL ~ +SPEED_FULL，代表 0 ~ 100% 占空比。
 *
 * 【为什么必须"换算"而不是只"限幅"】
 *   若只把 v 限幅到 ARR，一旦把 TIM2 配成 10kHz（PSC=0, ARR=7199），
 *   传 SPEED_FULL 进去占空比只有 13.9%，车会"能转但爬得极慢"，
 *   这种隐性故障在现场极难排查。换算之后无论 PSC/ARR 怎么配，
 *   ±SPEED_FULL 都是满占空比。
 * ------------------------------------------------------------ */
static uint16_t PwmFromSpeed(int v, TIM_HandleTypeDef *htim)
{
    int32_t arr;
    int32_t ccr;

    if (v >  SPEED_FULL) v =  SPEED_FULL;
    if (v < -SPEED_FULL) v = -SPEED_FULL;

    arr = (int32_t)__HAL_TIM_GET_AUTORELOAD(htim);       /* 当前 ARR */
    ccr = (int32_t)(v < 0 ? -v : v) * arr / SPEED_FULL;  /* 等比换算 */
    if (ccr > arr) ccr = arr;

    return (uint16_t)ccr;
}

/* ---------------- 启动 ---------------- */
void Motor_PWM_Start(void)
{
    /* 【关键】PB4 复位后默认是 NJTRST（JTAG 复位脚），不释放就当不了
     * 普通 IO —— 这是"独立电机 A 方向脚完全没反应"的根因。
     * 下面的宏把 SWJ_CFG 置为 0b010：关掉 JTAG、保留 SWD，
     * 所以 CLion / ST-Link 的下载和调试不受任何影响。
     * 千万别用 __HAL_AFIO_REMAP_SWJ_DISABLE()，那会连 SWD 一起关掉。 */
    __HAL_RCC_AFIO_CLK_ENABLE();
    __HAL_AFIO_REMAP_SWJ_NOJTAG();

    /* CubeMX 生成的 MX_TIMx_Init() 只是初始化，不会自动启动 PWM，
     * 必须显式调用下面 6 行，否则所有通道都没有输出。 */
    __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1, 0);
    __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_2, 0);
    __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, 0);
    __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, 0);
    Servo_SetAngle(90);
    Fan_Kill();
    if (HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_1) != HAL_OK) Error_Handler();
    if (HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_2) != HAL_OK) Error_Handler();
    if (HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_1) != HAL_OK) Error_Handler();
    if (HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_2) != HAL_OK) Error_Handler();
    if (HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_1) != HAL_OK) Error_Handler();
    if (HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_2) != HAL_OK) Error_Handler();

    Servo_SetAngle(90);                                        /* 舵机回中 */
    __HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_2, FAN_US_MIN);   /* 电调解锁油门 */

    Car_Move(0, 0);
    Independent_Motor_Set(1, 0);
    Independent_Motor_Set(2, 0);
}

/* ---------------- 履带差速 ---------------- */
void Car_Move(int leftSpeed, int rightSpeed)
{
    /* 左履带：PWM = TIM2_CH1 (PA0)，方向 = PB0 / PB1 */
    if (leftSpeed > 0) {
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_SET);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, GPIO_PIN_RESET);
    } else if (leftSpeed < 0) {
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_RESET);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, GPIO_PIN_SET);
    } else {
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_RESET);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, GPIO_PIN_RESET);
    }
    __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1, PwmFromSpeed(leftSpeed, &htim2));

    /* 右履带：PWM = TIM2_CH2 (PA1)，方向 = PB10 / PB11 */
    if (rightSpeed > 0) {
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_10, GPIO_PIN_SET);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_11, GPIO_PIN_RESET);
    } else if (rightSpeed < 0) {
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_10, GPIO_PIN_RESET);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_11, GPIO_PIN_SET);
    } else {
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_10, GPIO_PIN_RESET);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_11, GPIO_PIN_RESET);
    }
    __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_2, PwmFromSpeed(rightSpeed, &htim2));
}

void Car_Brake(void)
{
    /* Driver unknown: stop only, no guaranteed holding brake. */
    Car_Move(0, 0);
}

/* ---------------- 独立电机 ---------------- */
void Independent_Motor_Set(uint8_t motor_id, int speed)
{
    if (motor_id == 1) {
        /* 电机 A：PWM = TIM3_CH1 (PA6)，方向 = PB4 / PB5
         * 注意 PB4 必须先由 Motor_PWM_Start() 释放 JTAG 才能用！ */
        if (speed > 0) {
            HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, GPIO_PIN_SET);
            HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, GPIO_PIN_RESET);
        } else if (speed < 0) {
            HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, GPIO_PIN_RESET);
            HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, GPIO_PIN_SET);
        } else {
            HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, GPIO_PIN_RESET);
            HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, GPIO_PIN_RESET);
        }
        __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, PwmFromSpeed(speed, &htim3));

    } else if (motor_id == 2) {
        /* 电机 B：PWM = TIM3_CH2 (PA7)，方向 = PB8 / PB9 */
        if (speed > 0) {
            HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, GPIO_PIN_SET);
            HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9, GPIO_PIN_RESET);
        } else if (speed < 0) {
            HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, GPIO_PIN_RESET);
            HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9, GPIO_PIN_SET);
        } else {
            HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, GPIO_PIN_RESET);
            HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9, GPIO_PIN_RESET);
        }
        __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, PwmFromSpeed(speed, &htim3));
    }
}

/* ---------------- 舵机 ---------------- */
void Servo_SetAngle(uint16_t angle)
{
    uint32_t pulse;

    /* 必须限幅：若传入 999，脉宽会算成 4.6ms，舵机会直接烧掉 */
    if (angle > 180u) angle = 180u;

    pulse = SERVO_US_MIN
          + ((uint32_t)angle * (SERVO_US_MAX - SERVO_US_MIN)) / 180UL;
    __HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_1, (uint16_t)pulse);
}

/* ---------------- 涵道风扇（经电调） ---------------- */
static uint16_t fan_target = FAN_US_MIN;
static uint16_t fan_now    = FAN_US_MIN;

void Fan_SetSpeed(uint16_t us)
{
    if (us < FAN_US_MIN) us = FAN_US_MIN;
    if (us > FAN_US_MAX) us = FAN_US_MAX;   /* 10A 继电器：1500 封顶，绝不给 2000 */
    fan_target = us;
}

/* 斜坡逼近：上升 1us/ms（1000 -> 1500 约 500ms），下降快一倍。
 * 目的是压住无刷电机启动浪涌，避免继电器触点打毛/粘连，
 * 也避免大电流把 STM32 拉复位。必须每 10~20ms 调一次。 */
static uint32_t fan_last_tick = 0;
static uint8_t fan_tick_ready = 0;

void Fan_Tick(void)
{
    uint32_t now = HAL_GetTick();
    if (!fan_tick_ready) { fan_last_tick = now; fan_tick_ready = 1; return; }
    uint32_t dt = now - fan_last_tick;
    fan_last_tick = now;
    if (dt > 20u) dt = 20u;
    if (fan_now < fan_target) {
        uint32_t diff = fan_target - fan_now;
        fan_now += (uint16_t)(dt < diff ? dt : diff);
    } else {
        uint32_t diff = fan_now - fan_target;
        uint32_t step = dt * 2u;
        fan_now -= (uint16_t)(step < diff ? step : diff);
    }
    if (fan_now < FAN_US_MIN) fan_now = FAN_US_MIN;
    if (fan_now > FAN_US_MAX) fan_now = FAN_US_MAX;
    __HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_2, fan_now);
}

void Fan_Kill(void)
{
    fan_tick_ready = 0;
    fan_last_tick = HAL_GetTick();
    fan_target = FAN_US_MIN;
    fan_now    = FAN_US_MIN;
    __HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_2, FAN_US_MIN);
}

/* ============================================================
 *                    第二部分：遥控任务层
 * ============================================================
 * 按键分配：
 *   左摇杆 上/下 = 前进 / 后退
 *   左摇杆 左/右 = 左转 / 右转
 *   △ / ×       = 独立电机 A 正转 / 反转（点动）
 *   ○ / □       = 独立电机 B 正转 / 反转（点动）
 *   右摇杆 左/右 = 舵机 0° ~ 180°
 *   R1          = 涵道风扇点射（最长 3 秒，松手即收）
 *   L2          = 急停（履带短接刹车 + 风扇断电）
 * ============================================================ */

#define DEAD_ZONE       16u      /* 摇杆死区（以标定后的中位为 0 点，±16 刻度） */
#define LOOP_MS         20u      /* 控制周期 20ms */
#define LOST_MS         500u     /* 手柄失联超过 500ms -> 全车停机 */
#define CENTER_SAMPLES  16u      /* 用前 16 帧平均值标定摇杆中位 */
#define REINIT_MS       1000u    /* 连续读失败 1 秒 -> 重走一遍模拟模式配置 */

/* ------------------------------------------------------------
 * 摇杆原始值 -> -SPEED_FULL ~ +SPEED_FULL
 * ------------------------------------------------------------
 * center 是开机标定出来的真实中位。山寨 PS2 手柄静置时常常停在
 * 120 ~ 140 而不是 128，若固定拿 128 当零点，松手后车会自己慢慢
 * 往一个方向爬 —— 这是赛场上最常见、也最难当场想明白的坑。
 * 另外中位两侧的行程不一定相等，这里分别归一化，保证两个方向都能打满。
 * ------------------------------------------------------------ */
static int16_t StickMap(uint8_t raw, uint8_t center)
{
    int32_t v    = (int32_t)raw - (int32_t)center;
    int32_t span;

    if (v > -(int32_t)DEAD_ZONE && v < (int32_t)DEAD_ZONE) return 0;

    span = (v > 0) ? (int32_t)(255 - (int32_t)center) : (int32_t)center;
    if (span < 1) span = 1;

    v = v * (int32_t)SPEED_FULL / span;
    if (v >  (int32_t)SPEED_FULL) v =  (int32_t)SPEED_FULL;
    if (v < -(int32_t)SPEED_FULL) v = -(int32_t)SPEED_FULL;

    return (int16_t)v;
}

static int16_t Clamp16(int32_t v)
{
    if (v >  (int32_t)SPEED_FULL) v =  (int32_t)SPEED_FULL;
    if (v < -(int32_t)SPEED_FULL) v = -(int32_t)SPEED_FULL;
    return (int16_t)v;
}

const char *Robot_Version(void)
{
    return CRTC_FW_VERSION;
}

/* ---------------- 初始化 ---------------- */
void Robot_Init(void)
{
    Motor_PWM_Start();          /* 6 路 PWM + 释放 PB4 + 电调回最低油门 */

    /* 电调解锁顺序很关键：先让信号线持续输出 1000us，再给电调上电，
     * 会听到"哔-哔"两声表示解锁成功。若电调已经带电，这里保持
     * 2 秒最低油门同样能完成解锁。 */
    HAL_Delay(2000);

    PS2_Init();                 /* 失败也不致命，主循环里会持续重试 */
}

/* ---------------- 主循环任务（内部自带 20ms 节流） ---------------- */
void Robot_Loop(void)
{
    static uint32_t last_loop = 0;
    static uint32_t last_ok   = 0;
    static uint32_t fan_start = 0;
    static uint32_t fail_cnt  = 0;
    static uint8_t  fan_prev  = 0;
    static uint8_t  ps2_ready = 0;
    static uint16_t servo_ang = 90;

    /* 摇杆中位标定用的累加器 */
    static uint8_t  cent_n = 0;
    static uint32_t sum_lx = 0, sum_ly = 0, sum_rx = 0;
    static uint8_t  lx_c = 128, ly_c = 128, rx_c = 128;

    uint32_t now;
    uint8_t  ok;
    int16_t  fwd, turn, mA = 0, mB = 0, rx;
    int32_t  a;

    /* ---- 0) 节流到 20ms ---- */
    now = HAL_GetTick();
    if (now - last_loop < LOOP_MS) return;
    last_loop = now;

    /* ---- 1) 读手柄 ---- */
    ok = PS2_ReadData();
    if (ok)
    {
        ps2_ready = 1;
        fail_cnt  = 0;
        last_ok   = now;
    }
    else
    {
        Car_Move(0, 0);
        Independent_Motor_Set(1, 0);
        Independent_Motor_Set(2, 0);
        Fan_Kill();
        fail_cnt++;
        /* 连续 1 秒读不到：可能是手柄被拔掉又插回来，手柄已复位回
         * 数字模式，必须重走一遍"进入配置/模拟模式"的序列，否则
         * 永远读不到摇杆。 */
        if (ps2_ready && fail_cnt > (REINIT_MS / LOOP_MS))
        {
            ps2_ready = 0;
            fail_cnt  = 0;
        }
        if (!ps2_ready)
        {
            ps2_ready = PS2_Init();     /* 阻塞约 0.3s，仅在未连接时发生 */
            fail_cnt  = 0;
        }
    }

    /* ---- 2) 失效保护：失联超过 500ms 全停 ---- */
    if (now - last_ok > LOST_MS)
    {
        Car_Move(0, 0);
        Independent_Motor_Set(1, 0);
        Independent_Motor_Set(2, 0);
        Fan_Kill();
        return;
    }

    if (!ok || PS2_L2) {
        Car_Move(0, 0);
        Independent_Motor_Set(1, 0);
        Independent_Motor_Set(2, 0);
        Fan_Kill();
        return;
    }

    /* ---- 3) 摇杆中位标定（取前 16 帧有效数据的平均） ---- */
    if (cent_n < CENTER_SAMPLES)
    {
        sum_lx += PS2_LX();
        sum_ly += PS2_LY();
        sum_rx += PS2_RX();
        cent_n++;
        if (cent_n == CENTER_SAMPLES)
        {
            lx_c = (uint8_t)(sum_lx / CENTER_SAMPLES);
            ly_c = (uint8_t)(sum_ly / CENTER_SAMPLES);
            rx_c = (uint8_t)(sum_rx / CENTER_SAMPLES);
        }
        Car_Move(0, 0);
        Independent_Motor_Set(1, 0);
        Independent_Motor_Set(2, 0);
        Fan_Kill();
        return;
    }

    /* ---- 4) 履带差速（左摇杆） ---- */
    fwd  = -StickMap(PS2_LY(), ly_c);      /* 上推 -> LY 变小 -> 前进为正 */
    turn =  StickMap(PS2_LX(), lx_c);      /* 右推为正 -> 右转 */
    Car_Move(Clamp16(fwd + turn), Clamp16(fwd - turn));

    /* ---- 5) 独立电机：△/× 控 A，○/□ 控 B（点动） ---- */
    if (PS2_TRIANGLE) mA =  (int16_t)SPEED_FULL;
    if (PS2_CROSS)    mA = -(int16_t)SPEED_FULL;
    if (PS2_CIRCLE)   mB =  (int16_t)SPEED_FULL;
    if (PS2_SQUARE)   mB = -(int16_t)SPEED_FULL;
    Independent_Motor_Set(1, mA);
    Independent_Motor_Set(2, mB);

    /* ---- 6) 舵机：右摇杆 X 控角度，只在死区外更新（回中不抖） ---- */
    rx = StickMap(PS2_RX(), rx_c);
    if (rx != 0)
    {
        a = 90 + (int32_t)rx * 90 / (int32_t)SPEED_FULL;   /* 映射到 0~180 */
        if (a < 0)   a = 0;
        if (a > 180) a = 180;
        servo_ang = (uint16_t)a;
    }
    Servo_SetAngle(servo_ang);

    /* ---- 7) 涵道风扇：R1 点射，单次最长 3 秒 ---- */
    if (PS2_R1)
    {
        if (!fan_prev) fan_start = now;                    /* 记录按下时刻 */
        if (now - fan_start < FAN_BURST_MS) Fan_SetSpeed(FAN_US_MAX);
        else                                Fan_SetSpeed(FAN_US_MIN);  /* 超时保护 */
    }
    else
    {
        Fan_SetSpeed(FAN_US_MIN);
    }
    fan_prev = PS2_R1 ? 1u : 0u;

    /* ---- 8) 油门斜坡：必须每周期调用 ---- */
    Fan_Tick();

    /* ---- 9) L2 急停 ---- */
    if (PS2_L2)
    {
        Car_Brake();
        Independent_Motor_Set(1, 0);
        Independent_Motor_Set(2, 0);
        Fan_Kill();
    }
}
