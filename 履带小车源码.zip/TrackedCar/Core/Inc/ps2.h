/* ============================================================
 * ps2.h  ——  CRTC2026 履带车：PS2 手柄驱动接口
 * 版本：CRTC-PS2 v4   2026-10-16
 * 位置：Core/Inc/ps2.h
 *
 * 接线（接收器转接板）：DAT=PB12  CMD=PB13  CS=PB14  CLK=PB15
 *   DAT 必须配成 GPIO_Input + Pull-up，浮空会直接通信失败。
 * ============================================================ */
#ifndef __PS2_H
#define __PS2_H

#include "main.h"

#define CRTC_PS2_VERSION  "CRTC-PS2 v4 2026-10-16"

/* ------------------------------------------------------------
 * PS2 接收器一帧 9 字节，含义如下（摇杆中位约 0x80）：
 *   [0] = 从机首响应（通常 0xFF），主机发送 0x01
 *   [1] = 模式 ID：0x41 数字 / 0x73 模拟 / 0x79 压感模拟
 *   [2] = 0x5A                       就绪标志
 *   [3] = 按键组 1  低电平有效
 *   [4] = 按键组 2  低电平有效
 *   [5] = 右摇杆 X  [6] = 右摇杆 Y
 *   [7] = 左摇杆 X  [8] = 左摇杆 Y
 * ------------------------------------------------------------ */
extern uint8_t PS2_Data[9];

/* 初始化：进入模拟（红灯）模式。返回 1 表示握手成功。 */
uint8_t PS2_Init(void);

/* 读一帧。返回 1 表示本帧有效（手柄在线且帧格式正确）。 */
uint8_t PS2_ReadData(void);

/* ---------------- 摇杆原始值（0~255，中位约 128） ----------------
 * 注意：山寨手柄中位常在 120~140，不要直接拿 128 当零点，
 * motor.c 的 Robot_Loop() 里已做开机中位标定。 */
#define PS2_RX()   (PS2_Data[5])
#define PS2_RY()   (PS2_Data[6])
#define PS2_LX()   (PS2_Data[7])
#define PS2_LY()   (PS2_Data[8])

/* ---------------- 按键（低电平有效：按下 = 0） ---------------- */
#define PS2_KEY(byte, bit)  (((PS2_Data[byte] >> (bit)) & 0x01u) == 0u)

#define PS2_SELECT    PS2_KEY(3, 0)
#define PS2_L3        PS2_KEY(3, 1)
#define PS2_R3        PS2_KEY(3, 2)
#define PS2_START     PS2_KEY(3, 3)
#define PS2_UP        PS2_KEY(3, 4)
#define PS2_RIGHT     PS2_KEY(3, 5)
#define PS2_DOWN      PS2_KEY(3, 6)
#define PS2_LEFT      PS2_KEY(3, 7)

#define PS2_L2        PS2_KEY(4, 0)
#define PS2_R2        PS2_KEY(4, 1)
#define PS2_L1        PS2_KEY(4, 2)
#define PS2_R1        PS2_KEY(4, 3)
#define PS2_TRIANGLE  PS2_KEY(4, 4)
#define PS2_CIRCLE    PS2_KEY(4, 5)
#define PS2_CROSS     PS2_KEY(4, 6)
#define PS2_SQUARE    PS2_KEY(4, 7)

#endif
