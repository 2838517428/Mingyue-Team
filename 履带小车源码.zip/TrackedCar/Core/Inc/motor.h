/* ============================================================
 * motor.h  ——  CRTC2026 履带车：电机 / 舵机 / 涵道 驱动 + 遥控任务
 * 版本：CRTC-FW v4   2026-10-16
 * 位置：Core/Inc/motor.h
 *
 * 配套文件：motor.c / ps2.h / ps2.c
 * ============================================================ */
#ifndef __MOTOR_H
#define __MOTOR_H

#include "main.h"

/* 版本号：编译后可打印确认自己用的是哪一版 */
#define CRTC_FW_VERSION   "CRTC-FW v4 2026-10-16"

/* ------------------------------------------------------------
 * 油门 / 角度上限
 * Provisional pulse limits; pulse width does not guarantee current.
 * Verify actual ESC/servo specifications and current before powered tests.
 * ------------------------------------------------------------ */
#define FAN_US_MIN     1000u   /* Corrected ESC stop/arming command; not a hardware cutoff. */
#define FAN_US_MAX     1500u   /* Provisional command cap, NOT a current limiter. */
#define FAN_BURST_MS   3000u   /* 单次点射最长 3 秒，保护电机与继电器 */
#define SERVO_US_MIN   1000u   /* 舵机 0°   对应的脉宽 */
#define SERVO_US_MAX   2000u   /* 舵机 180° 对应的脉宽 */

/* 速度满量程：所有速度参数用 ±SPEED_FULL 表示 0~100% 占空比。
 * 具体 CCR 由驱动内部按定时器 ARR 等比换算，与 PSC/ARR 配置无关。 */
#define SPEED_FULL     1000

/* ============================================================
 * 一、驱动层接口
 * ============================================================ */

/* 启动 6 路 PWM、释放 PB4(NJTRST)、电调回最低油门、所有执行器归零。
 * Call once after peripheral init; Robot_Init() calls this internally. */
void Motor_PWM_Start(void);

/* 履带差速：速度取 -SPEED_FULL ~ +SPEED_FULL，正数前进、负数后退、0 自由滑行 */
void Car_Move(int leftSpeed, int rightSpeed);

/* Stop only; driver-dependent, no guaranteed holding brake. */
void Car_Brake(void);

/* 独立电机：motor_id = 1 或 2，速度量纲同 Car_Move */
void Independent_Motor_Set(uint8_t motor_id, int speed);

/* 舵机：0~180 度，内部已限幅 */
void Servo_SetAngle(uint16_t angle);

/* 涵道风扇：设定目标油门（内部限幅到 FAN_US_MIN ~ FAN_US_MAX） */
void Fan_SetSpeed(uint16_t us);

/* 油门斜坡推进：主循环里每 10~20ms 必须调一次 */
void Fan_Tick(void);

/* 立即回最低油门（急停 / 失联保护用） */
void Fan_Kill(void);

/* ============================================================
 * 二、遥控任务层接口
 * ============================================================ */

/* 初始化：启动 PWM、解锁电调、初始化 PS2 手柄。进主循环前调用一次。
 *   main.c 里：
 *     #include "motor.h"
 *     Robot_Init();
 *     while (1) { Robot_Loop(); }
 */
void Robot_Init(void);

/* 主循环任务：内部自带 20ms 节流。直接放在 while(1) 里，
 * 不要再叠加 HAL_Delay 或其它长阻塞。 */
void Robot_Loop(void);

/* 返回固件版本字符串，便于串口打印确认烧的是哪一版 */
const char *Robot_Version(void);

#endif
