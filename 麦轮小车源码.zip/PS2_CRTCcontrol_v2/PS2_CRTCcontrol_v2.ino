/* ============================================================================
 *  PS2 手柄版 v2.8 —— 麦克纳姆轮 + 车头切换 + 慢速横移（精简提速版）
 *  ----------------------------------------------------------------------------
 *  输入方式：PS2 手柄按键（PS2X_lib，轮询 + 掉线自动重连）
 *  动作方式：按住运行、松开停止（方向键 □ ○ △ L1 R1）；✕ 每按一次步进 90°
 *
 *  【v2.8 相对 v2.7 的改动：只瘦身提速，功能完全一样】
 *  1) 轮询周期 10ms → 2ms，按键响应快约 5 倍（库内部本身有 ≥1ms 的节拍，
 *     所以实际循环 ≈3ms；想更稳可把 PS2_POLL_MS 改回 5~10）
 *  2) 按键读取合并成一次位图读取 + 自己算"刚按下"的边沿，
 *     原来是每轮 ~10 次 ps2x.Button()/ButtonPressed() 函数调用
 *  3) 动作改成查表（MOTION[]），车头翻转改查表（INVERTED[]），
 *     删掉 switch 跳转和 cmdName() 字符串表
 *  4) 删掉 handleCommand() 这层转发，按键直接调用对应动作函数
 *  5) 删除全部串口调试输出（v2.7 已做，本版保持静默）
 *
 *  ===== 手柄按键表（麦克纳姆轮）=====
 *    ↑ 按住 → 前进（100%）          松开 → 停
 *    ↓ 按住 → 后退（100%）          松开 → 停
 *    ← 按住 → 左转（逆时针）100%     松开 → 停
 *    → 按住 → 右转（顺时针）100%     松开 → 停
 *    □ 按住 → 向左平移（100%）       松开 → 停
 *    ○ 按住 → 向右平移（100%）       松开 → 停
 *    L1 按住 → 慢速向左平移（50%）   松开 → 停
 *    R1 按住 → 慢速向右平移（50%）   松开 → 停
 *    △ 按住 → 舵机1（GPIO5，360°）连续转   松开 → 停
 *    ✕ 按一下 → 舵机2（GPIO6，SG90 180°）步进 90°（0→90→180→90→0）
 *    R2 按一下 → 车头翻转：前进/后退/左右平移/L1 R1 全部取反，← → 也对调
 *    SELECT 按一下 → 舵机停（GPIO5 停转，SG90 保持当前角度）
 *    左摇杆 → 也可当方向键用（不想用把 STICK_DEAD 改 0）
 *
 *  ===== 慢速原理 =====
 *    "慢速" = 马达 PWM 占空比 50%（≈50% 电压），用 LEDC 硬件 PWM 实现；
 *    全速动作走普通 GPIO，不占 LEDC 通道。ESP32-S3 共 8 个通道，够用。
 *
 *  ===== 接线 =====
 *    马达 IN1/IN2 = GPIO 1,19 / 3,4 / 7,8 / 9,10 ；舵机 = GPIO5 / GPIO6
 *    手柄 CLK=16 CMD=14 ATT=15 DAT=13（DAT棕 CMD橙 ATT黄 CLK蓝）
 *    SG90 建议单独 5V 供电并与 ESP32 共地，不要从 3.3V 引脚取电
 * ==========================================================================*/

#include "PS2X_lib.h"

// ===== PS2 手柄定义 =====
#define PS2_CLK        16      // 蓝线
#define PS2_CMD        14      // 橙线
#define PS2_ATT        15      // 黄线 = ATT / CS
#define PS2_DAT        13      // 棕线
#define PS2_POLL_MS    2       // 读手柄周期（2ms；库内部最少间隔 1ms，1.5s 内必须读一次）
#define RECONNECT_MS   2000UL  // 读不到手柄多久后重新握手
#define STICK_DEAD     25      // 左摇杆当方向键的判断门限，设 0 = 只用方向键

// 车头翻转时，← 左转 / → 右转 是否也跟着对调：1 = 对调（默认）
#define FLIP_TURN_WITH_HEADING  1

// ===== 马达定义：每个马达两根线 (IN1, IN2) =====
struct Motor {
  int in1;
  int in2;
};
const Motor MOTORS[4] = {
  {1,  19},  // 马达1
  {3,  4},   // 马达2
  {7,  8},   // 马达3
  {9, 10},   // 马达4
};

/* ======================= 方向标定表（麦克纳姆轮） ==========================
 *  4 个字符依次对应 马达1 / 马达2 / 马达3 / 马达4：
 *      '+' 正转    '-' 反转
 *  假设轮子布局： 马达1 = 左前, 马达3 = 左后, 马达2 = 右前, 马达4 = 右后
 *  哪个动作方向不对，只改对应那一行的字符即可。
 * ======================================================================== */
const char DIR_FORWARD[]  = "++++";   // ↑ 前进
const char DIR_BACKWARD[] = "----";   // ↓ 后退
const char DIR_TURN_L[]   = "-+-+";   // ← 左转（逆时针）
const char DIR_TURN_R[]   = "+-+-";   // → 右转（顺时针）
const char DIR_STRAFE_L[] = "-++-";   // □ 向左平移 / L1 慢速向左平移
const char DIR_STRAFE_R[] = "+--+";   // ○ 向右平移 / R1 慢速向右平移

// ===== 马达 PWM（调速用）=====
const int MOTOR_PWM_FREQ   = 2000;    // 2kHz
const int MOTOR_PWM_BITS   = 10;      // 10 位：0 ~ 1023
const int MOTOR_SPEED_FULL = 100;     // 全速 = 100%（普通 GPIO 拉高）
const int MOTOR_SPEED_SLOW = 50;      // 慢速 = 50% 占空比（≈50% 电压）

int g_pwmPins[4] = {-1, -1, -1, -1};  // 当前挂在 LEDC 上的马达引脚（最多 4 个）
int g_pwmCount   = 0;

// ===== 舵机定义 =====
const int SERVO_PINS[2] = {5, 6};   // 舵机0 = GPIO5, 舵机1 = GPIO6
const int SERVO_CH[2]   = {0, 1};   // LEDC 通道（仅 core 2.x 使用）
const int SERVO_360     = 0;        // GPIO5：360° 连续旋转舵机
const int SERVO_SG90    = 1;        // GPIO6：180° 位置舵机 SG90

// 360° 舵机（GPIO5）：脉宽只控速度/方向
const int SERVO_STOP_US = 1500;     // 停止脉宽
const int SERVO_RUN_US  = 1800;     // 正转
const int SERVO_REV_US  = 1200;     // 反转

// 180° 位置舵机（SG90，GPIO6）
const int SERVO180_MIN_US    = 544;   // 0°   脉宽
const int SERVO180_MAX_US    = 2400;  // 180° 脉宽
const int SERVO180_START_DEG = 0;     // 上电初始角度
const int SERVO180_STEP_DEG  = 90;    // 每按一次 ✕ 转过的角度
/* SG90 在两端有堵转声时：MIN_US 调 600、MAX_US 调 2300 */

int servo180Angle = SERVO180_START_DEG;
int servo180Dir   = 1;

// ===== 运行状态 =====
int      servoDir         = 1;      // 360° 舵机方向（每次按下翻转）
bool     g_servo360Held   = false;  // △ 是否正按住
uint8_t  g_appliedCmd     = 0;      // 已下发的实际动作，0 = 停
bool     g_headingReverse = false;  // 车头是否翻转
uint16_t g_prevButtons    = 0;      // 上一轮按键位图（用于算"刚按下"）

// ===== 舵机 PWM 参数 =====
const int SERVO_FREQ      = 50;      // 50Hz
const int SERVO_RES_BITS  = 14;      // 14 位
const int SERVO_PULSE_MIN = 500, SERVO_PULSE_MAX = 2500;

// ===== 指令号 =====
#define CMD_FORWARD    0x01
#define CMD_TURN_L     0x02
#define CMD_TURN_R     0x03
#define CMD_BACKWARD   0x04
#define CMD_SERVO2     0x05
#define CMD_SERVO1     0x06
#define CMD_SERVO_STOP 0x07
#define CMD_STRAFE_L   0x09
#define CMD_STRAFE_R   0x0A
#define CMD_SLOW_L     0x0B
#define CMD_SLOW_R     0x0C

// ===== 动作表：下标 = 指令号；pat == NULL 表示没有马达动作 =====
struct Motion {
  const char *pat;
  uint8_t     speed;
};
const Motion MOTION[13] = {
  {NULL, 0},                              // 0x00 停止
  {DIR_FORWARD,  MOTOR_SPEED_FULL},       // 0x01 前进
  {DIR_TURN_L,   MOTOR_SPEED_FULL},       // 0x02 左转
  {DIR_TURN_R,   MOTOR_SPEED_FULL},       // 0x03 右转
  {DIR_BACKWARD, MOTOR_SPEED_FULL},       // 0x04 后退
  {NULL, 0}, {NULL, 0}, {NULL, 0},        // 0x05~0x07 舵机指令
  {NULL, 0},                              // 0x08（保留）
  {DIR_STRAFE_L, MOTOR_SPEED_FULL},       // 0x09 左平移
  {DIR_STRAFE_R, MOTOR_SPEED_FULL},       // 0x0A 右平移
  {DIR_STRAFE_L, MOTOR_SPEED_SLOW},       // 0x0B 慢速左平移
  {DIR_STRAFE_R, MOTOR_SPEED_SLOW},       // 0x0C 慢速右平移
};

// ===== 车头翻转映射：下标 = 指令号 → 取反后的指令号 =====
const uint8_t INVERTED[13] = {
  0x00,
  CMD_BACKWARD,
#if FLIP_TURN_WITH_HEADING
  CMD_TURN_R,
  CMD_TURN_L,
#else
  CMD_TURN_L,
  CMD_TURN_R,
#endif
  CMD_FORWARD,
  CMD_SERVO2, CMD_SERVO1, CMD_SERVO_STOP,
  0x08,
  CMD_STRAFE_R,
  CMD_STRAFE_L,
  CMD_SLOW_R,
  CMD_SLOW_L,
};

// ===== 马达底层 =====
void motorPwmReleaseAll();

// 停所有马达。先释放 LEDC：core 3.x 里引脚被 LEDC 占用时 digitalWrite 不生效，
// 不释放的话松手后马达会一直按 PWM 转下去。
void stopAllMotors() {
  motorPwmReleaseAll();
  for (int i = 0; i < 4; i++) {
    pinMode(MOTORS[i].in1, OUTPUT);
    pinMode(MOTORS[i].in2, OUTPUT);
    digitalWrite(MOTORS[i].in1, LOW);
    digitalWrite(MOTORS[i].in2, LOW);
  }
}

// 把挂在 LEDC 上的马达引脚全部还给普通 GPIO（并拉低）
void motorPwmReleaseAll() {
#if ESP_ARDUINO_VERSION_MAJOR >= 3
  for (int i = 0; i < g_pwmCount; i++) {
    ledcDetach(g_pwmPins[i]);
    pinMode(g_pwmPins[i], OUTPUT);
    digitalWrite(g_pwmPins[i], LOW);
    g_pwmPins[i] = -1;
  }
  g_pwmCount = 0;
#endif
}

// 让一个引脚输出 PWM（占空比 0~1023）；返回 false 表示通道不够
bool motorPwmOn(int pin, int duty) {
#if ESP_ARDUINO_VERSION_MAJOR >= 3
  if (!ledcAttach(pin, MOTOR_PWM_FREQ, MOTOR_PWM_BITS)) return false;
  ledcWrite(pin, duty);
  if (g_pwmCount < 4) g_pwmPins[g_pwmCount++] = pin;
  return true;
#else
  (void)pin; (void)duty;
  return false;
#endif
}

// 按 4 字符模式表驱动四个马达：'+' 正转 / '-' 反转 / 其它 = 停
void applyPattern(const char *p, int speedPct) {
  motorPwmReleaseAll();

  for (int i = 0; i < 4; i++) {
    int activePin = -1, idlePin = -1;
    if      (p[i] == '+') { activePin = MOTORS[i].in1; idlePin = MOTORS[i].in2; }
    else if (p[i] == '-') { activePin = MOTORS[i].in2; idlePin = MOTORS[i].in1; }

    if (activePin < 0) {
      pinMode(MOTORS[i].in1, OUTPUT);
      pinMode(MOTORS[i].in2, OUTPUT);
      digitalWrite(MOTORS[i].in1, LOW);
      digitalWrite(MOTORS[i].in2, LOW);
      continue;
    }

    pinMode(idlePin, OUTPUT);
    digitalWrite(idlePin, LOW);          // 另一根线拉低 = 定方向

    if (speedPct >= MOTOR_SPEED_FULL) {
      pinMode(activePin, OUTPUT);
      digitalWrite(activePin, HIGH);
    } else if (!motorPwmOn(activePin, ((1 << MOTOR_PWM_BITS) - 1) * speedPct / 100)) {
      pinMode(activePin, OUTPUT);        // 通道不够就退化为全速
      digitalWrite(activePin, HIGH);
    }
  }
}

// 下发马达动作（按住运行、松开传 0）：只在动作真正变化时才动引脚
void applyMotorCmd(uint8_t cmd) {
  uint8_t eff = (cmd && g_headingReverse) ? INVERTED[cmd] : cmd;
  if (eff == g_appliedCmd) return;
  g_appliedCmd = eff;

  const Motion &m = MOTION[eff];
  if (m.pat) applyPattern(m.pat, m.speed);
  else       stopAllMotors();
}

void toggleHeading() {
  g_headingReverse = !g_headingReverse;
  // 下一轮 applyMotorCmd() 会发现"实际动作"变了，自动按新车头重新下发
}

// ===== 舵机 =====
void servoWrite(int idx, int us) {
  us = constrain(us, SERVO_PULSE_MIN, SERVO_PULSE_MAX);
  uint32_t duty = (uint32_t)us * (1UL << SERVO_RES_BITS) / (1000000UL / SERVO_FREQ);
#if ESP_ARDUINO_VERSION_MAJOR >= 3
  ledcWrite(SERVO_PINS[idx], duty);
#else
  ledcWrite(SERVO_CH[idx], duty);
#endif
}

int servo180Pulse(int deg) {
  deg = constrain(deg, 0, 180);
  return map(deg, 0, 180, SERVO180_MIN_US, SERVO180_MAX_US);
}

// SG90 转到指定角度并保持
void servo180Goto(int deg) {
  servo180Angle = constrain(deg, 0, 180);
  servoWrite(SERVO_SG90, servo180Pulse(servo180Angle));
}

// 每按一次 ✕ 步进 90°，到 0°/180° 后自动换向
void servo180Step() {
  int next = servo180Angle + servo180Dir * SERVO180_STEP_DEG;
  if (next > 180 || next < 0) {
    servo180Dir = -servo180Dir;
    next = servo180Angle + servo180Dir * SERVO180_STEP_DEG;
  }
  servo180Goto(next);
}

// 舵机停：GPIO5 停转，SG90 保持当前角度
void servoStopAll() {
  g_servo360Held = false;
  servoWrite(SERVO_360, SERVO_STOP_US);
  servo180Goto(servo180Angle);
}

// △：按住转、松开停（每次重新按下换向）
void servo360Held(bool held) {
  if (held == g_servo360Held) return;
  g_servo360Held = held;
  if (held) {
    servoDir = -servoDir;
    servoWrite(SERVO_360, servoDir > 0 ? SERVO_RUN_US : SERVO_REV_US);
  } else {
    servoWrite(SERVO_360, SERVO_STOP_US);
  }
}

void servoSetup(int idx) {
#if ESP_ARDUINO_VERSION_MAJOR >= 3
  if (!ledcAttach(SERVO_PINS[idx], SERVO_FREQ, SERVO_RES_BITS)) return;
#else
  ledcSetup(SERVO_CH[idx], SERVO_FREQ, SERVO_RES_BITS);
  ledcAttachPin(SERVO_PINS[idx], SERVO_CH[idx]);
#endif
  if (idx == SERVO_SG90) servoWrite(idx, servo180Pulse(SERVO180_START_DEG));
  else                   servoWrite(idx, SERVO_STOP_US);
}

// ===== PS2 手柄 =====
PS2X     ps2x;
bool     g_linkLost = false;
uint32_t g_lostAt   = 0;

bool ps2TryConnect() {
  delay(500);                                   // 接收头上电时间
  return ps2x.config_gamepad(PS2_CLK, PS2_CMD, PS2_ATT, PS2_DAT, false, false) == 0;
}

// 读按键 -> 执行（按住运行、松开停）；一次位图读取 + 边沿运算
void readPS2Keys() {
  uint16_t b    = ps2x.ButtonDataByte();        // 当前按下的按键位图（高有效）
  uint16_t edge = b & ~g_prevButtons;           // 本轮"刚按下"的按键
  g_prevButtons = b;

  /* 1) 按一下触发一次 */
  if (edge & PSB_R2)     toggleHeading();       // 车头翻转
  if (edge & PSB_CROSS)  servo180Step();        // ✕ SG90 步进 90°
  if (edge & PSB_SELECT) servoStopAll();        // SELECT 舵机停

  /* 2) 方向键 / 左摇杆 */
  bool up    = b & PSB_PAD_UP;
  bool down  = b & PSB_PAD_DOWN;
  bool left  = b & PSB_PAD_LEFT;
  bool right = b & PSB_PAD_RIGHT;

  if (STICK_DEAD > 0) {
    int lx = ps2x.Analog(PSS_LX);
    int ly = ps2x.Analog(PSS_LY);
    if (lx < 128 - STICK_DEAD) left  = true;
    if (lx > 128 + STICK_DEAD) right = true;
    if (ly < 128 - STICK_DEAD) up    = true;
    if (ly > 128 + STICK_DEAD) down  = true;
  }

  /* 3) 马达：优先级 方向键 > □ > ○ > L1 > R1；都没有 = 停 */
  uint8_t cmd = 0;
  if      (up && !down)    cmd = CMD_FORWARD;
  else if (down && !up)    cmd = CMD_BACKWARD;
  else if (left && !right) cmd = CMD_TURN_L;
  else if (right && !left) cmd = CMD_TURN_R;
  else if (b & PSB_SQUARE) cmd = CMD_STRAFE_L;
  else if (b & PSB_CIRCLE) cmd = CMD_STRAFE_R;
  else if (b & PSB_L1)     cmd = CMD_SLOW_L;
  else if (b & PSB_R1)     cmd = CMD_SLOW_R;
  applyMotorCmd(cmd);

  /* 4) 舵机1：按住 △ 一直转 */
  servo360Held(b & PSB_TRIANGLE);
}

// ================================= setup =================================
void setup() {
  stopAllMotors();                  // 马达引脚置输出并拉低

  for (int i = 0; i < 2; i++) servoSetup(i);
  delay(300);                       // 等供电稳定，再补发一次目标位置
  servoWrite(SERVO_360, SERVO_STOP_US);
  servo180Goto(SERVO180_START_DEG);

  while (!ps2TryConnect()) delay(100);   // 手柄要在模拟模式（ANALOG 灯亮）
  g_prevButtons = ps2x.ButtonDataByte(); // 清掉上电时的按键残留
}

// ================================= loop =================================
void loop() {
  /* PS2 手柄必须 1.5s 内被查询一次，否则掉线失联 */
  if (ps2x.read_gamepad(false, 0x00)) {
    g_linkLost = false;
    readPS2Keys();
  } else if (!g_linkLost) {
    g_linkLost = true;              // 掉线：读不到按键就收不到松手信号，必须停
    g_lostAt = millis();
    applyMotorCmd(0);
    servo360Held(false);
  } else if (millis() - g_lostAt >= RECONNECT_MS) {
    g_lostAt = millis();
    if (ps2TryConnect()) g_linkLost = false;
  }

  delay(PS2_POLL_MS);
}
